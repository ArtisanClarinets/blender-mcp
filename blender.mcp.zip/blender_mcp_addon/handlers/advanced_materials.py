"""
Advanced material and shading handlers for Blender MCP addon.

Implements PBR enhancements, subsurface scattering, volume materials, and anisotropic shaders.
"""

import json
import logging
from typing import Any, Dict, List, Optional
import bpy

logger = logging.getLogger("BlenderMCPTools")


def get_status() -> Dict[str, Any]:
    """Get advanced materials system status."""
    return {
        "status": "ready",
        "features": {
            "subsurface_scattering": True,
            "volume_materials": True,
            "anisotropic_materials": True,
            "layered_materials": True,
        },
    }


def create_subsurface_material(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create subsurface scattering material for organic surfaces.

    Parameters:
    - name: Material name
    - base_color: Base color [r, g, b]
    - subsurface_color: Subsurface scattering color [r, g, b]
    - subsurface_radius: Scattering radius [r, g, b]
    - subsurface_weight: Scattering strength (0-1)
    - subsurface_scale: Scale factor
    """
    # Early Exit: Validate required parameter
    name = params.get("name")
    if not name:
        raise ValueError("name is required")

    # Parse parameters with defaults (Parse Don't Validate)
    base_color = params.get("base_color", [0.8, 0.8, 0.8])
    subsurface_color = params.get("subsurface_color", [0.8, 0.4, 0.2])
    subsurface_radius = params.get("subsurface_radius", [1.0, 0.2, 0.1])
    subsurface_weight = params.get("subsurface_weight", 0.5)
    subsurface_scale = params.get("subsurface_scale", 1.0)

    # Fail Fast: Validate color values are within range
    for color_list, color_name in [
        (base_color, "base_color"),
        (subsurface_color, "subsurface_color"),
        (subsurface_radius, "subsurface_radius"),
    ]:
        if not isinstance(color_list, list) or len(color_list) != 3:
            raise ValueError(f"{color_name} must be a list of 3 values [r, g, b]")
        for val in color_list:
            if not 0 <= val <= 1:
                raise ValueError(f"{color_name} values must be between 0 and 1")

    if not 0 <= subsurface_weight <= 1:
        raise ValueError("subsurface_weight must be between 0 and 1")

    if subsurface_scale <= 0:
        raise ValueError("subsurface_scale must be greater than 0")

    # Create material with SSS
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    bsdf = nodes.get("Principled BSDF")

    if not bsdf:
        # Fail Fast: Principled BSDF should exist by default
        raise RuntimeError(
            f"Failed to create Principled BSDF node for material: {name}"
        )

    # Apply subsurface scattering properties
    bsdf.inputs["Base Color"].default_value = base_color + [1.0]
    bsdf.inputs["Subsurface Weight"].default_value = subsurface_weight
    bsdf.inputs["Subsurface Color"].default_value = subsurface_color + [1.0]
    bsdf.inputs["Subsurface Radius"].default_value = subsurface_radius
    bsdf.inputs["Subsurface Scale"].default_value = subsurface_scale

    logger.info(f"Created subsurface scattering material: {name}")

    return {
        "status": "success",
        "material_name": name,
        "type": "subsurface",
        "properties": {
            "base_color": base_color,
            "subsurface_weight": subsurface_weight,
            "subsurface_scale": subsurface_scale,
        },
    }


def create_volume_material(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create volume material for clouds, smoke, fire effects.

    Parameters:
    - name: Material name
    - volume_type: "cloud", "smoke", "fire", "fog"
    - density: Volume density
    - color: Volume color
    - emission_strength: For fire effects
    """
    # Early Exit: Validate required parameter
    name = params.get("name")
    if not name:
        raise ValueError("name is required")

    # Parse parameters with defaults (Parse Don't Validate)
    volume_type = params.get("volume_type", "cloud")
    density = params.get("density", 1.0)
    color = params.get("color", [1.0, 1.0, 1.0])
    emission_strength = params.get("emission_strength", 0.0)

    # Fail Fast: Validate volume_type
    valid_volume_types = ["cloud", "smoke", "fire", "fog"]
    if volume_type not in valid_volume_types:
        raise ValueError(f"volume_type must be one of: {valid_volume_types}")

    # Fail Fast: Validate color values
    if not isinstance(color, list) or len(color) != 3:
        raise ValueError("color must be a list of 3 values [r, g, b]")
    for val in color:
        if not 0 <= val <= 1:
            raise ValueError("color values must be between 0 and 1")

    if density <= 0:
        raise ValueError("density must be greater than 0")

    if emission_strength < 0:
        raise ValueError("emission_strength must be non-negative")

    # Create material with volume shader
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # Get output node
    output = nodes.get("Material Output")
    if not output:
        raise RuntimeError(
            f"Failed to create Material Output node for material: {name}"
        )

    # Create volume scatter node
    volume_scatter = nodes.new("ShaderNodeVolumeScatter")
    volume_scatter.inputs["Density"].default_value = density
    volume_scatter.inputs["Color"].default_value = color + [1.0]

    # Connect volume scatter to output
    links.new(volume_scatter.outputs["Volume"], output.inputs["Volume"])

    # Add emission for fire effects
    if volume_type == "fire" and emission_strength > 0:
        # Create emission node
        emission = nodes.new("ShaderNodeEmission")
        emission.inputs["Color"].default_value = [
            1.0,
            0.5,
            0.0,
            1.0,
        ]  # Orange fire color
        emission.inputs["Strength"].default_value = emission_strength

        # Mix volume and emission
        mix_shader = nodes.new("ShaderNodeMixShader")
        mix_shader.inputs["Fac"].default_value = 0.5

        links.new(volume_scatter.outputs["Volume"], mix_shader.inputs[1])
        links.new(emission.outputs["Emission"], mix_shader.inputs[2])
        links.new(mix_shader.outputs["Shader"], output.inputs["Volume"])

    logger.info(f"Created volume material: {name} (type: {volume_type})")

    return {
        "status": "success",
        "material_name": name,
        "volume_type": volume_type,
        "properties": {
            "density": density,
            "color": color,
            "emission_strength": emission_strength if volume_type == "fire" else None,
        },
    }


def create_anisotropic_material(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create anisotropic material for hair, fabric, brushed metal.

    Parameters:
    - name: Material name
    - base_color: Base color
    - anisotropic: Anisotropic strength (-1 to 1)
    - anisotropic_rotation: Rotation angle
    - roughness: Surface roughness
    - metallic: Metallic factor
    """
    # Early Exit: Validate required parameter
    name = params.get("name")
    if not name:
        raise ValueError("name is required")

    # Parse parameters with defaults (Parse Don't Validate)
    base_color = params.get("base_color", [0.8, 0.8, 0.8])
    anisotropic = params.get("anisotropic", 0.5)
    anisotropic_rotation = params.get("anisotropic_rotation", 0.0)
    roughness = params.get("roughness", 0.3)
    metallic = params.get("metallic", 0.0)

    # Fail Fast: Validate color values
    if not isinstance(base_color, list) or len(base_color) != 3:
        raise ValueError("base_color must be a list of 3 values [r, g, b]")
    for val in base_color:
        if not 0 <= val <= 1:
            raise ValueError("base_color values must be between 0 and 1")

    if not -1 <= anisotropic <= 1:
        raise ValueError("anisotropic must be between -1 and 1")

    if not 0 <= anisotropic_rotation <= 1:
        raise ValueError("anisotropic_rotation must be between 0 and 1")

    if not 0 <= roughness <= 1:
        raise ValueError("roughness must be between 0 and 1")

    if not 0 <= metallic <= 1:
        raise ValueError("metallic must be between 0 and 1")

    # Create material with anisotropic properties
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    bsdf = nodes.get("Principled BSDF")

    if not bsdf:
        raise RuntimeError(
            f"Failed to create Principled BSDF node for material: {name}"
        )

    # Apply anisotropic properties
    bsdf.inputs["Base Color"].default_value = base_color + [1.0]
    bsdf.inputs["Anisotropic"].default_value = anisotropic
    bsdf.inputs["Anisotropic Rotation"].default_value = anisotropic_rotation
    bsdf.inputs["Roughness"].default_value = roughness
    bsdf.inputs["Metallic"].default_value = metallic

    logger.info(f"Created anisotropic material: {name}")

    return {
        "status": "success",
        "material_name": name,
        "type": "anisotropic",
        "properties": {
            "base_color": base_color,
            "anisotropic": anisotropic,
            "roughness": roughness,
            "metallic": metallic,
        },
    }


def create_layered_material(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create layered material with multiple material layers.

    Parameters:
    - name: Material name
    - layers: List of layer configurations
    """
    # Early Exit: Validate required parameter
    name = params.get("name")
    if not name:
        raise ValueError("name is required")

    # Parse parameters with defaults (Parse Don't Validate)
    layers = params.get("layers", [])

    # Fail Fast: Validate layers
    if not isinstance(layers, list):
        raise ValueError("layers must be a list")

    if len(layers) == 0:
        logger.warning(f"Creating layered material '{name}' with no layers")

    # Create base material
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    # Get output node
    output = nodes.get("Material Output")
    if not output:
        raise RuntimeError(
            f"Failed to create Material Output node for material: {name}"
        )

    # Create layered shader using mix nodes
    previous_shader = None

    for i, layer in enumerate(layers):
        if not isinstance(layer, dict):
            logger.warning(f"Skipping invalid layer {i}: not a dictionary")
            continue

        # Create a Principled BSDF for this layer
        layer_bsdf = nodes.new("ShaderNodeBsdfPrincipled")
        layer_bsdf.name = f"Layer_{i}_BSDF"
        layer_bsdf.label = f"Layer {i}"

        # Apply layer properties if specified
        if "base_color" in layer:
            color = layer["base_color"]
            if isinstance(color, list) and len(color) == 3:
                layer_bsdf.inputs["Base Color"].default_value = color + [1.0]

        if "roughness" in layer:
            layer_bsdf.inputs["Roughness"].default_value = layer["roughness"]

        if "metallic" in layer:
            layer_bsdf.inputs["Metallic"].default_value = layer["metallic"]

        # Mix with previous layer or connect directly
        if previous_shader is None:
            # First layer - connect directly to output
            links.new(layer_bsdf.outputs["BSDF"], output.inputs["Surface"])
            previous_shader = layer_bsdf
        else:
            # Create mix shader to blend layers
            mix_shader = nodes.new("ShaderNodeMixShader")
            mix_shader.name = f"Layer_Mix_{i}"

            # Get mix factor from layer or default to 0.5
            mix_factor = layer.get("mix_factor", 0.5)
            if not 0 <= mix_factor <= 1:
                mix_factor = 0.5
            mix_shader.inputs["Fac"].default_value = mix_factor

            # Connect previous shader and current layer
            links.new(previous_shader.outputs["BSDF"], mix_shader.inputs[1])
            links.new(layer_bsdf.outputs["BSDF"], mix_shader.inputs[2])

            # If this is the last layer, connect to output
            if i == len(layers) - 1:
                links.new(mix_shader.outputs["Shader"], output.inputs["Surface"])

            previous_shader = mix_shader

    # If no layers were processed, ensure we have at least a basic material
    if previous_shader is None:
        bsdf = nodes.get("Principled BSDF")
        if bsdf:
            links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])

    layer_count = len([n for n in nodes if "Layer_" in n.name])
    logger.info(f"Created layered material: {name} with {layer_count} layers")

    return {
        "status": "success",
        "material_name": name,
        "layer_count": len(layers),
        "layers_processed": layer_count,
    }
