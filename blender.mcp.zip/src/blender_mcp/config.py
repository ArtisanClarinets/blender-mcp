"""
Configuration for Blender MCP

Defines default values and environment variable overrides for various settings.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class TelemetryConfig:
    """Configuration for telemetry settings."""

    enabled: bool = True
    supabase_url: Optional[str] = None
    supabase_key: Optional[str] = None
    anonymous: bool = True
    tool_tracking: bool = True
    performance_tracking: bool = True
    max_batch_size: int = 100


@dataclass
class BlenderMCPConfig:
    """Main configuration for Blender MCP."""

    host: str = "localhost"
    port: int = 9876
    connection_timeout: int = 30
    max_retries: int = 3
    retry_delay: float = 1.0
    disable_telemetry: bool = False

    # Asset integrations
    polyhaven_enabled: bool = True
    sketchfab_enabled: bool = True
    hyper3d_enabled: bool = True
    hunyuan3d_enabled: bool = True

    # Export settings
    default_export_dir: str = "exports"
    draco_compression: bool = True
    texture_embed: bool = True
    y_up: bool = True


# Load configuration from environment variables


def load_config() -> BlenderMCPConfig:
    """Load configuration from environment variables."""
    from os import getenv

    config = BlenderMCPConfig(
        host=getenv("BLENDER_HOST", "localhost"),
        port=int(getenv("BLENDER_PORT", "9876")),
        disable_telemetry=getenv("DISABLE_TELEMETRY", "").lower()
        in ["1", "true", "yes"],
        polyhaven_enabled=getenv("POLYHAVEN_ENABLED", "true").lower()
        not in ["false", "0", "no"],
        sketchfab_enabled=getenv("SKETCHFAB_ENABLED", "true").lower()
        not in ["false", "0", "no"],
        hyper3d_enabled=getenv("HYPER3D_ENABLED", "true").lower()
        not in ["false", "0", "no"],
        hunyuan3d_enabled=getenv("HUNYUAN3D_ENABLED", "true").lower()
        not in ["false", "0", "no"],
        default_export_dir=getenv("BLENDER_MCP_EXPORT_DIR", "exports"),
        draco_compression=getenv("BLENDER_MCP_DRACO", "true").lower()
        not in ["false", "0", "no"],
        texture_embed=getenv("BLENDER_MCP_TEXTURE_EMBED", "true").lower()
        not in ["false", "0", "no"],
        y_up=getenv("BLENDER_MCP_Y_UP", "true").lower() not in ["false", "0", "no"],
    )

    return config


# Load telemetry configuration


def load_telemetry_config() -> TelemetryConfig:
    """Load telemetry configuration from environment variables."""
    from os import getenv

    config = TelemetryConfig(
        enabled=not getenv("BLENDER_MCP_DISABLE_TELEMETRY", "").lower()
        in ["1", "true", "yes"],
        supabase_url=getenv("BLENDER_MCP_SUPABASE_URL"),
        supabase_key=getenv("BLENDER_MCP_SUPABASE_KEY"),
        anonymous=getenv("BLENDER_MCP_ANONYMOUS", "true").lower()
        not in ["false", "0", "no"],
        tool_tracking=getenv("BLENDER_MCP_TOOL_TRACKING", "true").lower()
        not in ["false", "0", "no"],
        performance_tracking=getenv("BLENDER_MCP_PERFORMANCE_TRACKING", "true").lower()
        not in ["false", "0", "no"],
    )

    return config


# Global configuration
config = load_config()
telemetry_config = load_telemetry_config()
